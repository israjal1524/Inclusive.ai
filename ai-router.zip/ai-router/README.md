# AI Router

An intelligent chatbot that automatically selects the best AI model (OpenAI, Claude, Gemini, Mistral, Cohere) based on the user's prompt.

## Structure
```
ai-router/
├── server/          # Node.js + Express backend
│   ├── routes/      # API route handlers
│   ├── services/    # AI provider adapters + router logic
│   ├── middleware/  # Rate limiting, auth
│   └── utils/       # Classifier, logger
└── client/          # React frontend
    └── src/
        ├── components/
        ├── hooks/
        └── api/
```

## Setup

### Server
```bash
cd server
npm install
cp .env.example .env   # add your API keys
npm run dev
```

### Client
```bash
cd client
npm install
npm run dev
```
